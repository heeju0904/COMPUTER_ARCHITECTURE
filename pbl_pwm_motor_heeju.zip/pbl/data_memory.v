//==============================================================================
// Data Memory with MMIO
// Normal RAM:  addr[31:0] < 0x0090  → word-aligned RAM
// 0x0090      switches (read-only)  → 8-bit external input
// 0x0098      pwm_duty (write-only) → 8-bit PWM duty cycle
// 0x009C      pwm_en   (write-only) → 1-bit PWM enable
//
// Writes are synchronous (posedge clk).
// Reads are combinational (no-latency address decode).
//==============================================================================
`timescale 1ns / 1ps

module data_memory #(
    parameter WIDTH = 32,
    parameter DEPTH = 256
)(
    input  wire        clk,
    input  wire        mem_write_en,
    input  wire [31:0] addr,
    input  wire [31:0] write_data,
    output reg  [31:0] read_data,

    // MMIO ports (connect to top-level)
    input  wire [7:0]  switches,     // 0x90: external switch input
    output reg  [7:0]  pwm_duty,     // 0x98: duty cycle register
    output reg         pwm_en        // 0x9C: enable register
);
    reg [WIDTH-1:0] ram [0:DEPTH-1];

    // -------------------------------------------------------------------------
    // Synchronous Write (RAM + MMIO registers)
    // -------------------------------------------------------------------------
    always @(posedge clk) begin
        if (mem_write_en) begin
            case (addr[7:0])
                8'h98: pwm_duty <= write_data[7:0];   // MMIO: PWM duty
                8'h9C: pwm_en   <= write_data[0];     // MMIO: PWM enable
                default: ram[addr[31:2]] <= write_data; // Normal RAM
            endcase
        end
    end

    // -------------------------------------------------------------------------
    // Combinational Read (RAM + MMIO registers)
    // -------------------------------------------------------------------------
    always @(*) begin
        case (addr[7:0])
            8'h90:   read_data = {24'd0, switches};   // MMIO: switches
            8'h98:   read_data = {24'd0, pwm_duty};   // MMIO: duty readback
            8'h9C:   read_data = {31'd0, pwm_en};     // MMIO: enable readback
            default: read_data = ram[addr[31:2]];     // Normal RAM
        endcase
    end

    // Power-on defaults
    initial begin
        pwm_duty = 8'd0;
        pwm_en   = 1'b0;
    end

endmodule
