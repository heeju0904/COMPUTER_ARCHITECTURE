`timescale 1ns / 1ps

module mips_tb;
    reg         clk;
    reg         rst_n;
    reg  [7:0]  switches;
    wire        pwm_out;
    wire [31:0] pc_out;
    wire [31:0] alu_result;

    mips uut (
        .clk      (clk),
        .rst_n    (rst_n),
        .switches (switches),
        .pwm_out  (pwm_out),
        .pc_out   (pc_out),
        .alu_result(alu_result)
    );

    // 10ns clock period (100 MHz)
    initial begin clk = 0; forever #5 clk = ~clk; end

    // Waveform dump
    initial begin
        $dumpfile("wave.vcd");
        $dumpvars(0, mips_tb);
    end

    initial begin
        switches = 8'd128;  // mid-value for Option B / not used in Option A
        rst_n    = 0;
        #20;
        rst_n = 1;

        $display("==============================================");
        $display("  MIPS PWM Motor Controller — Option A       ");
        $display("  Ramp-up -> Hold -> Ramp-down -> Hold       ");
        $display("==============================================");
        $display("Time(ns) | PC       | PWM_duty | pwm_out | ALU");
        $display("---------|----------|----------|---------|----");

        // Run for enough cycles to observe at least one full profile cycle
        // delay_lim=80, step=5, max=200: ramp steps=40, hold=20 → ~60*80*10ns each
        // Total ~100k cycles should show full profile
        repeat (150000) begin
            @(negedge clk);
            // Display every 256 PWM counter cycles for readability
            if (uut.u_datapath.u_data_mem.pwm_duty % 10 == 0)
                $display("%8t | %8h | %8d | %7b | %d",
                    $time, pc_out,
                    uut.u_datapath.u_data_mem.pwm_duty,
                    pwm_out,
                    alu_result);
        end

        $display("==============================================");
        $display("  Simulation Complete");
        $display("  Final duty = %0d, pwm_en = %0b",
            uut.u_datapath.u_data_mem.pwm_duty,
            uut.u_datapath.u_data_mem.pwm_en);
        $display("==============================================");
        $finish;
    end
endmodule
