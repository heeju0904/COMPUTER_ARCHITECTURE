//==============================================================================
// PWM Controller
// Architecture: 8-bit free-running counter + comparator
// pwm_out = 1 while counter < duty, 0 otherwise
// PWM period = 256 × T_clk
//==============================================================================
`timescale 1ns / 1ps

module pwm_controller (
    input  wire       clk,
    input  wire       rst_n,
    input  wire       en,         // enable: 1=run, 0=output forced to 0
    input  wire [7:0] duty,       // duty cycle: 0=0%, 255=~100%
    output wire       pwm_out     // PWM square wave output
);
    reg [7:0] counter;

    // Free-running 8-bit counter
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n)
            counter <= 8'd0;
        else if (en)
            counter <= counter + 8'd1;
        else
            counter <= 8'd0;
    end

    // Comparator: high while counter < duty
    assign pwm_out = en & (counter < duty);

endmodule
