`timescale 1ns / 1ps

module hazard_unit (
    input  wire [4:0] rs_E, rt_E,
    input  wire [4:0] write_reg_M, write_reg_W,
    input  wire       reg_write_M, reg_write_W,
    input  wire [4:0] rs_D, rt_D,
    input  wire [4:0] write_reg_E,
    input  wire       reg_write_E,
    input  wire [4:0] rt_E_load,
    input  wire       mem_to_reg_E,
    output reg  [1:0] forward_a_E, forward_b_E,
    output reg  [1:0] forward_a_D, forward_b_D,
    output wire       stall_F, stall_D, flush_E
);
    always @(*) begin
        if (reg_write_M && (write_reg_M != 0) && (write_reg_M == rs_E))      forward_a_E = 2'b10;
        else if (reg_write_W && (write_reg_W != 0) && (write_reg_W == rs_E)) forward_a_E = 2'b01;
        else                                                                   forward_a_E = 2'b00;
        if (reg_write_M && (write_reg_M != 0) && (write_reg_M == rt_E))      forward_b_E = 2'b10;
        else if (reg_write_W && (write_reg_W != 0) && (write_reg_W == rt_E)) forward_b_E = 2'b01;
        else                                                                   forward_b_E = 2'b00;
    end
    always @(*) begin
        if (reg_write_M && (write_reg_M != 0) && (write_reg_M == rs_D))      forward_a_D = 2'b10;
        else if (reg_write_W && (write_reg_W != 0) && (write_reg_W == rs_D)) forward_a_D = 2'b01;
        else                                                                   forward_a_D = 2'b00;
        if (reg_write_M && (write_reg_M != 0) && (write_reg_M == rt_D))      forward_b_D = 2'b10;
        else if (reg_write_W && (write_reg_W != 0) && (write_reg_W == rt_D)) forward_b_D = 2'b01;
        else                                                                   forward_b_D = 2'b00;
    end
    wire lwstall      = mem_to_reg_E && ((rt_E_load == rs_D) || (rt_E_load == rt_D));
    wire branch_stall = reg_write_E && (write_reg_E != 0) &&
                        ((write_reg_E == rs_D) || (write_reg_E == rt_D));
    assign stall_F = lwstall | branch_stall;
    assign stall_D = lwstall | branch_stall;
    assign flush_E = lwstall | branch_stall;
endmodule
