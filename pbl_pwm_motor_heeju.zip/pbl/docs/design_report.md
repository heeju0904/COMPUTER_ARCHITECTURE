# Design Report — MIPS PWM Motor Controller

## 1. Introduction

This project integrates a 5-stage pipelined MIPS CPU, a Memory-Mapped I/O bridge, and a PWM peripheral into a single working system. The CPU executes a MIPS assembly program that implements a motor speed profile (Option A: ramp-up → hold → ramp-down → hold → repeat), writing duty-cycle values through MMIO to a hardware PWM controller that produces a variable-width square wave.

---

## 2. System Architecture

```
                    ┌────────────────────────────────────────┐
                    │           mips.v (Top-Level)           │
  clk ─────────────►│                                        │
  rst_n ───────────►│  ┌──────────┐    ┌──────────────────┐ │
  switches[7:0] ───►│  │ control_ │    │    datapath.v    │ │
                    │  │ unit.v   │◄──►│  IF/ID/EX/MEM/WB │ │
                    │  └──────────┘    │                  │ │
                    │  ┌──────────┐    │  data_memory.v   │ │
                    │  │ hazard_  │◄──►│  (RAM + MMIO)    │ │
                    │  │ unit.v   │    └────────┬─────────┘ │
                    │  └──────────┘             │pwm_duty   │
                    │  ┌──────────────────────┐ │pwm_en     │
                    │  │   pwm_controller.v   │◄┘           │
                    │  │  counter + cmp       │             │
                    │  └──────────┬───────────┘             │
                    │             │                         │
  pwm_out ◄─────────│─────────────┘                         │
                    └────────────────────────────────────────┘
```

| Module                | Job                                               |
|-----------------------|---------------------------------------------------|
| `mips.v`              | Top-level wiring of CPU, hazard unit, PWM         |
| `datapath.v`          | 5-stage pipeline: IF, ID, EX, MEM, WB            |
| `control_unit.v`      | Decodes opcode → control signals                  |
| `main_decoder.v`      | Truth table: opcode → {reg_write, alu_src, …}    |
| `alu_decoder.v`       | alu_op + funct → alu_ctrl                         |
| `hazard_unit.v`       | Forwarding selectors, load-use stall, branch stall|
| `alu.v`               | ADD/SUB/AND/OR/SLT operations                     |
| `reg_file.v`          | 32 × 32-bit registers, async read / sync write   |
| `pc.v`                | Program counter with stall enable                 |
| `instruction_memory.v`| ROM, loads `memfile.dat` at start                 |
| `data_memory.v`       | RAM with MMIO decoder for switches/PWM registers  |
| `pwm_controller.v`    | 8-bit counter + comparator → `pwm_out`            |

---

## 3. MMIO Design

### Address Map

| Address | Device     | Direction  | Notes                    |
|---------|------------|------------|--------------------------|
| 0x0000+ | RAM        | read/write | Normal data memory       |
| 0x0090  | switches   | read-only  | 8-bit external input     |
| 0x0098  | pwm_duty   | write-only | 8-bit duty cycle (0–255) |
| 0x009C  | pwm_en     | write-only | 1-bit PWM enable         |

### Address Decoding

`data_memory.v` decodes addresses using `addr[7:0]` in a `case` statement:

```verilog
case (addr[7:0])
    8'h90: read_data  = {24'd0, switches};   // read-only
    8'h98: pwm_duty  <= write_data[7:0];     // write-only
    8'h9C: pwm_en    <= write_data[0];       // write-only
    default: ram[addr[31:2]] <= write_data;  // normal RAM
endcase
```

**Why synchronous writes, combinational reads:**  
Writes must be registered so they are stable for exactly one clock cycle, preventing glitches to the PWM peripheral. Reads are combinational so that `lw` instructions can present data to the WB stage without an extra latency cycle.

---

## 4. PWM Controller Design

### Counter + Comparator

```
clk ──► [8-bit counter 0→255→0→…] ──► [comparator]
                                            │  duty[7:0] ◄── MMIO 0x98
                                            ▼
                                        pwm_out = (counter < duty)
```

- The counter increments by 1 every clock cycle when `en = 1`.
- The comparator output is `1` while `counter < duty`, giving a high-time proportional to `duty / 256`.

### Duty-Cycle to Waveform

| duty value | High fraction | Effective ratio |
|------------|--------------|-----------------|
| 0          | 0/256        | 0% (always low) |
| 64         | 64/256       | 25%             |
| 128        | 128/256      | 50%             |
| 200        | 200/256      | ~78%            |
| 255        | 255/256      | ~100%           |

### PWM Frequency

With a 100 MHz system clock (T_clk = 10 ns):

```
PWM period = 256 × T_clk = 256 × 10 ns = 2.56 µs  (~390 kHz)
```

---

## 5. Software Algorithm

**Profile chosen: Option A — Ramp-up → Hold → Ramp-down → Hold → Repeat**

### Pseudocode

```
t0 = 0         // current duty
t1 = 200       // maximum duty
t2 = 5         // step size
t5 = 80        // delay loop limit

sw $s0, 0x9C   // PWM enable = 1

RAMP_UP:
    sw t0, 0x98        // write duty to PWM
    delay(t5)          // wait ~80 cycles
    t0 = t0 + t2       // increase duty
    if (t1 >= t0): goto RAMP_UP
    t0 = t1            // clamp to max

HOLD_MAX (×20 iterations):
    sw t0, 0x98
    delay(t5)

RAMP_DOWN:
    sw t0, 0x98
    delay(t5)
    t0 = t0 - t2       // decrease duty
    if (t0 >= t2): goto RAMP_DOWN
    t0 = 0             // clamp to 0

HOLD_ZERO (×20 iterations):
    sw t0, 0x98
    delay(t5)

goto RAMP_UP
```

### Register Map

| Register | Role           | Value    |
|----------|----------------|----------|
| `$t0`    | current duty   | 0–200    |
| `$t1`    | max duty       | 200      |
| `$t2`    | step size      | 5        |
| `$t4`    | delay counter  | 0–79     |
| `$t5`    | delay limit    | 80       |
| `$t8`    | hold counter   | 0–19     |
| `$s0`    | enable value   | 1        |

### Delay Loop Rate

Each delay loop runs `t5 = 80` iterations. With pipeline overhead (~3 instructions per iteration), one delay call ≈ 240 clock cycles = 2.4 µs. Each ramp step therefore takes ~2.4 µs, and 40 steps (0→200 in steps of 5) ≈ 96 µs for a full ramp.

---

## 6. Reflection

**One thing harder than expected:**  
Getting the early branch forwarding correct for `bne`/`beq` when the compared registers were written just one instruction before. A simple MEM/WB-only forwarding scheme missed the case where the result was still in EX. Adding a `branch_stall` signal in `hazard_unit.v` that detects EX-stage writes to registers needed by the ID-stage branch comparison solved the problem cleanly.

**One thing to change with more time:**  
Replace the hand-encoded `memfile.dat` with a lightweight Python/Perl assembler that takes MIPS assembly text as input and outputs hex automatically. This would make it much easier to experiment with different speed profiles without manually recalculating branch offsets.
