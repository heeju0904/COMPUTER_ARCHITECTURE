//==============================================================================
// MIPS 5-Stage Pipelined Processor (Top-Level) — PBL PWM Edition
// Added ports: switches (input), pwm_out (output)
//==============================================================================
`timescale 1ns / 1ps

module mips (
    input  wire        clk,
    input  wire        rst_n,
    input  wire [7:0]  switches,      // MMIO: 8-bit switch input (0x90)
    output wire        pwm_out,       // PWM square wave output
    output wire [31:0] pc_out,        // PC for debug
    output wire [31:0] alu_result     // WB result for debug
);
    // -------------------------------------------------------------------------
    // 1. Internal wires
    // -------------------------------------------------------------------------
    wire [31:0] instr_D;
    wire        reg_write_D, mem_to_reg_D, mem_write_D, branch_D;
    wire        alu_src_D, reg_dst_D;
    wire [2:0]  alu_ctrl_D;

    wire [4:0]  rs_D, rt_D, rs_E, rt_E, write_reg_E, write_reg_M, write_reg_W;
    wire        reg_write_M, reg_write_W, mem_to_reg_E, reg_write_E;
    wire [1:0]  forward_a_E, forward_b_E, forward_a_D, forward_b_D;
    wire        stall_F, stall_D, flush_E;

    // MMIO wires
    wire [7:0]  pwm_duty;
    wire        pwm_en;

    // -------------------------------------------------------------------------
    // 2. Control Unit
    // -------------------------------------------------------------------------
    control_unit u_control (
        .opcode    (instr_D[31:26]),
        .funct     (instr_D[5:0]),
        .mem_to_reg(mem_to_reg_D),
        .mem_write (mem_write_D),
        .branch    (branch_D),
        .alu_src   (alu_src_D),
        .reg_dst   (reg_dst_D),
        .reg_write (reg_write_D),
        .alu_ctrl  (alu_ctrl_D)
    );

    // -------------------------------------------------------------------------
    // 3. Hazard Unit
    // -------------------------------------------------------------------------
    hazard_unit u_hazard (
        .rs_E         (rs_E),
        .rt_E         (rt_E),
        .write_reg_M  (write_reg_M),
        .reg_write_M  (reg_write_M),
        .write_reg_W  (write_reg_W),
        .reg_write_W  (reg_write_W),
        .rs_D         (rs_D),
        .rt_D         (rt_D),
        .write_reg_E  (write_reg_E),
        .reg_write_E  (reg_write_E),
        .rt_E_load    (rt_E),
        .mem_to_reg_E (mem_to_reg_E),
        .forward_a_E  (forward_a_E),
        .forward_b_E  (forward_b_E),
        .forward_a_D  (forward_a_D),
        .forward_b_D  (forward_b_D),
        .stall_F      (stall_F),
        .stall_D      (stall_D),
        .flush_E      (flush_E)
    );

    // -------------------------------------------------------------------------
    // 4. Datapath
    // -------------------------------------------------------------------------
    datapath u_datapath (
        .clk           (clk),
        .rst_n         (rst_n),
        .reg_write_D   (reg_write_D),
        .mem_to_reg_D  (mem_to_reg_D),
        .mem_write_D   (mem_write_D),
        .alu_ctrl_D    (alu_ctrl_D),
        .alu_src_D     (alu_src_D),
        .reg_dst_D     (reg_dst_D),
        .branch_D      (branch_D),
        .forward_a_E   (forward_a_E),
        .forward_b_E   (forward_b_E),
        .forward_a_D   (forward_a_D),
        .forward_b_D   (forward_b_D),
        .stall_F       (stall_F),
        .stall_D       (stall_D),
        .flush_E       (flush_E),
        .rs_D          (rs_D),
        .rt_D          (rt_D),
        .rs_E          (rs_E),
        .rt_E          (rt_E),
        .write_reg_E   (write_reg_E),
        .reg_write_E   (reg_write_E),
        .mem_to_reg_E  (mem_to_reg_E),
        .write_reg_M   (write_reg_M),
        .reg_write_M   (reg_write_M),
        .write_reg_W   (write_reg_W),
        .reg_write_W   (reg_write_W),
        .instr_out_D   (instr_D),
        .pc_out        (pc_out),
        .alu_result_out(alu_result),
        // MMIO
        .switches      (switches),
        .pwm_duty      (pwm_duty),
        .pwm_en        (pwm_en)
    );

    // -------------------------------------------------------------------------
    // 5. PWM Controller
    // -------------------------------------------------------------------------
    pwm_controller u_pwm (
        .clk    (clk),
        .rst_n  (rst_n),
        .en     (pwm_en),
        .duty   (pwm_duty),
        .pwm_out(pwm_out)
    );

endmodule
