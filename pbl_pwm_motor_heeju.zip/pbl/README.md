# MIPS PWM Motor Controller

A 5-stage pipelined MIPS processor driving a PWM motor controller through Memory-Mapped I/O.

## System Block Diagram

```
┌──────────────────────────────────────────────────────────┐
│                      YOUR FINAL SYSTEM                   │
│                                                          │
│  ┌─────────┐    ┌────────────┐    ┌──────────────────┐  │
│  │  MIPS   │    │    MMIO    │    │  PWM Controller  │  │
│  │  CPU    │───►│ data_memory│───►│ counter + cmp    │──►pwm_out
│  │         │    │  (0x98/9C) │    │  duty[7:0]       │  │
│  └─────────┘    └────────────┘    └──────────────────┘  │
│   Software       Address-decode    Hardware peripheral   │
│   (memfile.dat)  bridge            (8-bit duty cycle)    │
└──────────────────────────────────────────────────────────┘
```

## MMIO Address Map

| Address | Device     | Direction  | Notes                   |
|---------|------------|------------|-------------------------|
| 0x0000+ | RAM        | read/write | Normal data memory      |
| 0x0090  | switches   | read-only  | 8-bit external input    |
| 0x0098  | PWM duty   | write-only | 8-bit duty cycle (0–255)|
| 0x009C  | PWM enable | write-only | 1-bit on/off            |

## How to Build and Run

```bash
# Compile and simulate
make

# Open waveform viewer
make wave
```

Requires: `iverilog`, `vvp`, `gtkwave`

## What You Will See

After reset, the PWM duty register ramps from 0 to 200 in steps of 5, holds at 200 for ~20 delay loops, ramps back down to 0, holds at 0, then repeats indefinitely. In GTKWave, `pwm_out` shows an increasingly wide pulse during ramp-up and a narrowing pulse during ramp-down.

## File Layout

```
pbl/
├── README.md               ← This file
├── Makefile                ← Build & simulation commands
├── memfile.dat             ← Motor-control program (hex)
├── mips.v                  ← Top-level CPU + PWM ports
├── mips_tb.v               ← Testbench
├── datapath.v              ← 5-stage pipelined datapath
├── data_memory.v           ← RAM + MMIO decoder
├── pwm_controller.v        ← PWM peripheral
├── control_unit.v          ← Opcode decoder wrapper
├── main_decoder.v          ← Main control signals
├── alu_decoder.v           ← ALU operation decoder
├── hazard_unit.v           ← Forwarding + stall logic
├── alu.v                   ← 32-bit ALU
├── reg_file.v              ← 32×32 register file
├── pc.v                    ← Program counter
├── instruction_memory.v    ← ROM (loads memfile.dat)
└── docs/
    ├── design_report.md
    └── test_report.md
```
