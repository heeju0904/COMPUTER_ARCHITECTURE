# Class 13: Final PBL Demo

> **Week 13 | Hanyang University ERICA Campus | Department of Robotics**  
> **Computer Architecture Course - Final Lab**

---

## 🎓 Course Summary

Congratulations on completing the entire MIPS CPU design course! Over the past 12 weeks, you have:

```
Week 01-05: Single-Cycle CPU Basics
  ├── ALU Design
  ├── Register File
  ├── Memory & PC
  ├── Datapath
  └── Control Unit

Week 06-09: 5-Stage Pipeline
  ├── Pipeline Registers
  ├── Early Branch Resolution
  ├── Data Forwarding
  └── Stall & Flush

Week 10-12: System Integration
  ├── Jump Instructions
  ├── MMIO Interface
  └── PWM Motor Control

Week 13: 🏆 Final Demo
```

---

## 📚 Demo Objectives

This week you will demonstrate a **complete embedded system**:

### Demo Scenario: Interactive Motor Controller

1. **User Input**: Set target speed via Switches
2. **CPU Processing**: Read input, calculate PWM duty cycle
3. **Hardware Output**: PWM controller drives motor
4. **Status Feedback**: LED displays current running state

```
  ┌─────────────────────────────────────────────────────────────┐
  │                   Complete System Demo                      │
  │                                                             │
  │   ┌──────────┐    ┌─────────────────┐    ┌──────────────┐  │
  │   │ Switches │───→│                 │───→│     PWM      │──│──→ Motor
  │   │ (Target) │    │    MIPS CPU     │    │  Controller  │  │
  │   └──────────┘    │   (Algorithm)   │    └──────────────┘  │
  │                   │                 │                       │
  │   ┌──────────┐    │                 │                       │
  │   │   LEDs   │←───│                 │                       │
  │   │ (Status) │    └─────────────────┘                       │
  │   └──────────┘                                              │
  └─────────────────────────────────────────────────────────────┘
```

---

## 💻 Demo Program Design

### Program Flow

```
Start
  │
  ├──→ Read Switches (target speed)
  │
  ├──→ Read current PWM Duty
  │
  ├──→ Calculate difference: target - current
  │
  ├──→ If current < target: accelerate (duty++)
  │    If current > target: decelerate (duty--)
  │    If equal: maintain
  │
  ├──→ Write new PWM Duty
  │
  ├──→ Update LED status
  │
  └──→ Delay and loop
```

### Assembly Code Example

```assembly
# ============================================
# Final Demo: Interactive Motor Speed Control
# ============================================
# MMIO Addresses:
#   0x90: Switches (read)  - Target Speed
#   0x94: LEDs (write)     - Status Display
#   0x98: PWM Duty (write) - Motor Speed

main:
    addi $t0, $zero, 0      # current_duty = 0
    sw   $t0, 0x98($zero)   # Initialize PWM = 0

control_loop:
    # Read target speed (Switches)
    lw   $t1, 0x90($zero)   # target = switches

    # Compare current with target
    slt  $t2, $t0, $t1      # t2 = (current < target)
    bne  $t2, $zero, accelerate

    slt  $t2, $t1, $t0      # t2 = (target < current)
    bne  $t2, $zero, decelerate
    
    j    update             # Equal, maintain

accelerate:
    addi $t0, $t0, 1        # current_duty++
    j    update

decelerate:
    addi $t0, $t0, -1       # current_duty--

update:
    sw   $t0, 0x98($zero)   # Update PWM duty
    sw   $t0, 0x94($zero)   # Update LED display

    # Delay loop (control change rate)
    addi $t3, $zero, 100
delay:
    addi $t3, $t3, -1
    bne  $t3, $zero, delay

    j    control_loop       # Infinite loop
```

---

## 📊 Grading Criteria

### 1. Functional Correctness (40%)

| Item | Score | Description |
|------|-------|-------------|
| CPU runs normally | 10% | No pipeline deadlock |
| Switches read correctly | 10% | MMIO input function |
| PWM output correct | 10% | Duty cycle changes as expected |
| LED display correct | 10% | Reflects current state |

### 2. Waveform Presentation (30%)

| Item | Score | Description |
|------|-------|-------------|
| PC changes correctly | 10% | No abnormal jumps |
| Pipeline signals correct | 10% | stall/flush at correct timing |
| PWM waveform standard | 10% | Smooth duty cycle changes |

### 3. Code Quality (20%)

| Item | Score | Description |
|------|-------|-------------|
| Modular design | 10% | Clear structure, defined responsibilities |
| Complete comments | 10% | Key logic explained |

### 4. Demo Performance (10%)

| Item | Score | Description |
|------|-------|-------------|
| Clear explanation | 5% | Can explain design approach |
| Answer questions | 5% | Can answer technical questions |

---

## 🧪 Testing Procedure

### Step 1: Compile and run
```bash
cd class_13
make
```

### Step 2: View waveform
```bash
make wave
```

### Step 3: Demo Verification Points

1. **Startup Phase**
   - [ ] CPU starts execution from address 0x00
   - [ ] PWM duty initializes to 0
   - [ ] LED initial display is 0

2. **Acceleration Phase**
   - [ ] Switches set to higher value (e.g., 0x80)
   - [ ] PWM duty gradually increases
   - [ ] LED follows duty changes

3. **Steady State Phase**
   - [ ] Duty stays unchanged after reaching target
   - [ ] PWM waveform is stable

4. **Deceleration Phase**
   - [ ] Switches set to lower value (e.g., 0x20)
   - [ ] PWM duty gradually decreases
   - [ ] LED follows changes

---

## 📁 File Structure

```
class_13/
├── alu.v                   # ALU
├── alu_decoder.v           # ALU decoder
├── control_unit.v          # Control unit
├── main_decoder.v          # Main decoder
├── data_memory.v           # Data memory with MMIO
├── datapath.v              # 5-stage pipelined datapath
├── hazard_unit.v           # Hazard handling unit
├── instruction_memory.v    # Instruction memory
├── pc.v                    # Program counter
├── reg_file.v              # Register file
├── pwm_controller.v        # PWM controller
├── mips.v                  # CPU top module
├── mips_tb.v               # Testbench
├── memfile.dat             # Demo program
└── Makefile
```

---

## 🔍 FAQ

### Q1: PWM has no output during simulation?
**A**: Check if `pwm_en` signal is correctly set. Need to write 1 to address 0x9C.

### Q2: LED doesn't follow Switches changes?
**A**: Check if program has correct loop structure. Make sure `j control_loop` is not skipped.

### Q3: Waveform shows pipeline always stalling?
**A**: Check for Load-Use hazard causing deadlock. Ensure instruction after `lw` doesn't immediately depend on loaded data.

---

## 🏆 Course Completion Certificate

After completing this course, you have mastered:

| Skill | Description |
|-------|-------------|
| **Digital Circuit Design** | Combinational logic, sequential logic, FSM |
| **Processor Architecture** | 5-stage pipeline, datapath, control unit |
| **Hazard Handling** | Forwarding, stall, flush mechanisms |
| **Embedded Systems** | MMIO, peripheral control, software-hardware integration |
| **Verilog HDL** | Modular design, simulation verification |

```
  ╔═══════════════════════════════════════════════════════════╗
  ║                                                           ║
  ║              🎉 CONGRATULATIONS! 🎉                      ║
  ║                                                           ║
  ║     You have successfully completed the                   ║
  ║     Computer Architecture Course!                         ║
  ║                                                           ║
  ║     You have built a working 5-stage pipelined           ║
  ║     MIPS CPU with PWM motor control capability.          ║
  ║                                                           ║
  ╚═══════════════════════════════════════════════════════════╝
```

---

## 📚 What's Next?

| Direction | Suggestions |
|-----------|-------------|
| **Advanced Architecture** | Superscalar, out-of-order execution, branch prediction |
| **FPGA Implementation** | Burn design to real hardware |
| **RISC-V** | Learn open-source ISA |
| **Embedded Linux** | Run an OS on your CPU |

---

**Previous**: [Class 12 - PWM Motor Control](../class_12/README.md)  

---

> *"The only way to learn a new programming language is by writing programs in it."*  
> *— Dennis Ritchie*
>
> Similarly, the best way to learn computer architecture is to build a CPU with your own hands!
